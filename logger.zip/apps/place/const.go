package place

const (
	AppName = "place"
)
