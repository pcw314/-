package position

const (
	AppName = "position"
)
