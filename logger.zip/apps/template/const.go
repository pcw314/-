package template

const (
	AppName = "template"
)
