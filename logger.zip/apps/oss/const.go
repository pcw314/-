package oss

const (
	AppName = "oss"
)
