package user

const (
	AppName = "user"
)
