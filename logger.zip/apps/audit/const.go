package audit

const (
	AppName = "audit"
)
